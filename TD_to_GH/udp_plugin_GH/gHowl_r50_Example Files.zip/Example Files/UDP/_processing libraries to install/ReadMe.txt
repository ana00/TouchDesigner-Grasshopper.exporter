Unpack and place the *.zip contents in the Libraries folder 
of your processing sketchbook directory.